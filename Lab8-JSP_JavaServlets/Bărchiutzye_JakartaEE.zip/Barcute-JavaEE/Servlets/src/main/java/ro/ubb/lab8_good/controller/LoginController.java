package ro.ubb.lab8_good.controller;

import ro.ubb.lab8_good.model.Authenticator;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LoginController extends HttpServlet {

    private static int nrOfPlayers;

    public LoginController() {
        super();
        nrOfPlayers = 0;
    }

    public static void resetNrPlayers() {
        nrOfPlayers = 0;
    }

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        System.out.println(username + " " + password);
        Authenticator authenticator = new Authenticator();
        String result = authenticator.authenticate(username, password);
        if(result.equals("error")) {
            request.getRequestDispatcher("login-error.jsp")
                    .forward(request, response);
        }
        else {
            RequestDispatcher rd = null;

            if (nrOfPlayers < 2) {
                nrOfPlayers += 1;
                rd = request.getRequestDispatcher("/success.jsp");

            } else {
                rd = request.getRequestDispatcher("/error.jsp");
            }
//            System.out.println(this.players);
            rd.forward(request, response);
        }
    }

}
