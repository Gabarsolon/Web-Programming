package ro.ubb.lab8_good.model;

public class PlayData {
    public Double userId;

    public PlayData() {
        userId = Math.random();
    }
}
