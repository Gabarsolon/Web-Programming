# Barcute-JavaEE
Battleship game created in JavaEE(Servlets + JSP)
